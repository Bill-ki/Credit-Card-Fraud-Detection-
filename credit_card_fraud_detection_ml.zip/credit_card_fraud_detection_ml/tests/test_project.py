from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data/processed/transactions_processed.csv"

def test_dataset_exists():
    assert DATA.exists()

def test_target_is_binary():
    df=pd.read_csv(DATA)
    assert set(df["is_fraud"].unique()).issubset({0,1})

def test_dataset_is_imbalanced():
    df=pd.read_csv(DATA)
    assert df["is_fraud"].mean() < 0.20