"""
One-off script (not part of the package) to execute the full workflow,
save the trained model, and produce report figures + metrics JSON.
"""
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score,
    average_precision_score, roc_curve, precision_recall_curve
)

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from train import load_data, build_models

ROOT = Path(__file__).resolve().parents[1]
MODELS_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"
MODELS_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)

features = [
    "amount_log","hour","distance_from_home_km","transactions_last_24h",
    "merchant_risk_score","account_age_days","online_transaction",
    "international_transaction","device_changed","night_transaction"
]

df = load_data()
X, y = df[features], df["is_fraud"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=.2, stratify=y, random_state=42
)

models = build_models()
all_results = {}
proba_by_model = {}

for name, model in models.items():
    model.fit(X_train, y_train)
    p = model.predict_proba(X_test)[:, 1]
    pred = (p >= 0.50).astype(int)
    proba_by_model[name] = p

    metrics = {
        "roc_auc": float(roc_auc_score(y_test, p)),
        "average_precision": float(average_precision_score(y_test, p)),
        "confusion_matrix_at_0.5": confusion_matrix(y_test, pred).tolist(),
        "classification_report_at_0.5": classification_report(y_test, pred, output_dict=True),
    }

    # threshold sweep
    sweep = []
    for t in [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80]:
        pt = (p >= t).astype(int)
        cm = confusion_matrix(y_test, pt, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel()
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        sweep.append({"threshold": t, "tp": int(tp), "fp": int(fp), "fn": int(fn), "tn": int(tn),
                       "precision": round(precision, 4), "recall": round(recall, 4), "f1": round(f1, 4)})
    metrics["threshold_sweep"] = sweep

    all_results[name] = metrics
    joblib.dump(model, MODELS_DIR / f"{name}.joblib")

# Random forest feature importances
rf_model = models["random_forest"].named_steps["model"]
importances = dict(sorted(
    zip(features, rf_model.feature_importances_.tolist()),
    key=lambda kv: kv[1], reverse=True
))
all_results["random_forest_feature_importance"] = importances

(REPORTS_DIR / "metrics.json").write_text(json.dumps(all_results, indent=2))

# --- Figures ---
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for name, p in proba_by_model.items():
    fpr, tpr, _ = roc_curve(y_test, p)
    axes[0].plot(fpr, tpr, label=f"{name} (AUC={roc_auc_score(y_test,p):.3f})")
axes[0].plot([0, 1], [0, 1], "k--", linewidth=1)
axes[0].set_xlabel("False Positive Rate"); axes[0].set_ylabel("True Positive Rate")
axes[0].set_title("ROC Curve"); axes[0].legend(fontsize=8)

for name, p in proba_by_model.items():
    prec, rec, _ = precision_recall_curve(y_test, p)
    axes[1].plot(rec, prec, label=f"{name} (AP={average_precision_score(y_test,p):.3f})")
axes[1].set_xlabel("Recall"); axes[1].set_ylabel("Precision")
axes[1].set_title("Precision-Recall Curve"); axes[1].legend(fontsize=8)
plt.tight_layout()
plt.savefig(REPORTS_DIR / "roc_pr_curves.png", dpi=150)
plt.close()

plt.figure(figsize=(6, 4))
names = list(importances.keys())
vals = list(importances.values())
plt.barh(names[::-1], vals[::-1], color="#3b6fa0")
plt.title("Random Forest Feature Importance")
plt.tight_layout()
plt.savefig(REPORTS_DIR / "feature_importance.png", dpi=150)
plt.close()

print("Saved models to", MODELS_DIR)
print("Saved metrics.json and figures to", REPORTS_DIR)
for name in models:
    m = all_results[name]
    print(f"\n{name}: ROC-AUC={m['roc_auc']:.4f}  AP={m['average_precision']:.4f}")
