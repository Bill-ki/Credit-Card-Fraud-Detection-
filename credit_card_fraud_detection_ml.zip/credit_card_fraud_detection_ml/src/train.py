from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, average_precision_score

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed" / "transactions_processed.csv"

def load_data():
    return pd.read_csv(DATA)

def build_models():
    features = [
        "amount_log","hour","distance_from_home_km","transactions_last_24h",
        "merchant_risk_score","account_age_days","online_transaction",
        "international_transaction","device_changed","night_transaction"
    ]
    numeric = features
    prep = ColumnTransformer([("num", Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scale", StandardScaler())
    ]), numeric)], remainder="drop")

    return {
        "logistic_regression": Pipeline([
            ("prep", prep),
            ("model", LogisticRegression(class_weight="balanced", max_iter=1000))
        ]),
        "random_forest": Pipeline([
            ("prep", prep),
            ("model", RandomForestClassifier(
                n_estimators=300, max_depth=12, min_samples_leaf=3,
                class_weight="balanced_subsample", random_state=42, n_jobs=-1
            ))
        ])
    }

def train_and_evaluate():
    df = load_data()
    features = [
        "amount_log","hour","distance_from_home_km","transactions_last_24h",
        "merchant_risk_score","account_age_days","online_transaction",
        "international_transaction","device_changed","night_transaction"
    ]
    X, y = df[features], df["is_fraud"]
    X_train,X_test,y_train,y_test=train_test_split(
        X,y,test_size=.2,stratify=y,random_state=42
    )
    results={}
    for name,model in build_models().items():
        model.fit(X_train,y_train)
        p=model.predict_proba(X_test)[:,1]
        pred=(p>=.50).astype(int)
        results[name]={
            "roc_auc": float(roc_auc_score(y_test,p)),
            "average_precision": float(average_precision_score(y_test,p)),
            "confusion_matrix": confusion_matrix(y_test,pred).tolist(),
            "report": classification_report(y_test,pred,output_dict=True)
        }
    return results

if __name__ == "__main__":
    results=train_and_evaluate()
    for name,r in results.items():
        print(name, "ROC-AUC:", round(r["roc_auc"],4),
              "Average Precision:", round(r["average_precision"],4))