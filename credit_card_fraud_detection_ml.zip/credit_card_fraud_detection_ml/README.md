# Credit Card Fraud Detection

Machine learning project that flags suspicious credit card transactions. Built to show how to handle a real imbalanced classification problem, not just get a high accuracy number.

## Problem

A bank needs to catch fraudulent transactions without shutting down too many legitimate ones. Missing fraud costs money directly. Blocking too many good transactions annoys customers and burns investigator time. Both sides matter, and this project treats them that way.

## Dataset

Synthetic portfolio dataset of 20,000 transactions (2.44% fraud rate). Fields include transaction amount, time of day, distance from home, recent transaction velocity, merchant risk score, account age, and a few behavioral flags (online, international, device changed, night transaction).

## Approach

Raw data goes through feature engineering, a stratified train/test split, and two class weighted models. Predictions are scored by probability rather than a hard label, then evaluated across multiple thresholds instead of just the default 0.5.

## Models

* Logistic Regression, used as an interpretable baseline
* Random Forest, used to capture nonlinear patterns

## Why not just use accuracy

Fraud is rare here (under 3% of transactions). A model that predicts "not fraud" every time would score over 97% accuracy and be completely useless. That's why this project reports precision, recall, F1 score, ROC AUC, and Average Precision instead, and looks at how those numbers move as the decision threshold changes.

## Results

Stratified 80/20 split, random_state=42.

| Model | ROC AUC | Average Precision | Precision @0.5 | Recall @0.5 | F1 @0.5 |
|---|---|---|---|---|---|
| Logistic Regression | 0.718 | 0.084 | 0.044 | 0.629 | 0.083 |
| Random Forest | 0.688 | 0.052 | 0.167 | 0.010 | 0.019 |

Neither model is production ready as is. Average Precision under 0.10 means most flagged transactions are false alarms at any recall level worth having, which is a fair outcome for a synthetic, weakly separable dataset like this one. Logistic Regression's balanced class weight makes it catch 63% of fraud at the default threshold, but at only 4% precision. Random Forest stays conservative at 0.5 and barely flags anything until the threshold is lowered.

Threshold sweep on Random Forest:

| Threshold | Precision | Recall | F1 |
|---|---|---|---|
| 0.10 | 0.032 | 0.876 | 0.062 |
| 0.20 | 0.044 | 0.505 | 0.080 |
| 0.30 | 0.060 | 0.247 | 0.097 |
| 0.50 | 0.167 | 0.010 | 0.019 |

Lowering the threshold is the whole story here: it trades precision for recall, and the right point depends on how expensive a missed fraud case is versus a wasted investigation.

Top features by importance in the Random Forest model: amount (log scaled), merchant risk score, distance from home, account age, and hour of day. These five carry most of the model's signal, which lines up with the recommendation below about combining risk signals.

Full metrics for both models, at every threshold, are saved in `reports/metrics.json`. The ROC and precision recall curves are in `reports/roc_pr_curves.png`, and the feature importance chart is in `reports/feature_importance.png`. Trained models are saved in `models/logistic_regression.joblib` and `models/random_forest.joblib`.

## What I'd recommend in a real deployment

* Route high risk transactions to manual review instead of auto rejecting on a single score
* Pick the probability threshold based on the actual cost of a missed fraud versus the cost of a false alarm, not a default 0.5
* Retrain and monitor regularly, since fraud patterns shift over time
* Pay closer attention to transactions that combine high merchant risk with an unusual location, a device change, and high recent transaction velocity, since those factors show up together in the flagged cases

## Project structure

```text
credit_card_fraud_detection_ml/
├── data/raw/transactions_raw.csv
├── data/processed/transactions_processed.csv
├── notebooks/fraud_detection.ipynb
├── src/train.py
├── src/run_full.py
├── tests/test_project.py
├── models/
├── reports/
├── requirements.txt
├── .gitignore
└── README.md
```

## Running it locally

```bash
python -m venv .venv
source .venv/bin/activate   # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/train.py
pytest
```

To reproduce the full run (trains both models, saves them, and regenerates the report figures):

```bash
python src/run_full.py
```

To explore the analysis step by step:

```bash
jupyter notebook notebooks/fraud_detection.ipynb
```

## Limitations

The data is synthetic, so it doesn't capture the messiness of real customer transactions and the fraud signal is intentionally weak. Treat the metrics above as a demonstration of a proper imbalanced classification workflow, not a claim about how this would perform on real transaction data.

## Portfolio summary

**Credit Card Fraud Detection | Python, Scikit-learn, Machine Learning**
Built an imbalanced classification pipeline to flag suspicious transactions. Engineered behavioral features, compared Logistic Regression and Random Forest, and evaluated results with precision, recall, F1 score, ROC AUC, and Average Precision instead of accuracy alone.
